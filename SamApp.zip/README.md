# SamApp
Minimal Android Java app for Sam Online Service (debug build).
Build with: gradle assembleDebug
