Simple Gradle wrapper helper (uses system gradle)
-----------------------------------------------
Files included:
  - gradlew          -> Unix shell script (make executable)
  - gradlew.bat      -> Windows batch wrapper
  - README-GRADLE-WRAPPER.txt (this file)

How to use (in GitHub Codespaces or any machine with gradle installed):
1) Upload this ZIP to your repo root (or copy files into your project root).
2) If you uploaded ZIP, unzip it in project root:
     unzip Sam-gradle-wrapper-lite.zip -d .
3) Make gradlew executable (only on Unix / Codespaces):
     chmod +x gradlew
4) Run the Gradle build (example):
     ./gradlew assembleDebug   # to build debug APK
   or
     ./gradlew assembleRelease # for release
Notes:
- This lightweight wrapper does NOT include gradle-wrapper.jar. It simply calls the system 'gradle' command.
- Use Codespaces (or install Gradle on your machine) so the 'gradle' command works.
- If you want a full official Gradle Wrapper (that downloads Gradle automatically), tell me and I will prepare full wrapper files.
